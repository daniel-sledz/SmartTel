import java.awt.Rectangle;

public class Przycisk {
    public final String obrazek;
    public final Rectangle obszar;
    public final Runnable akcja;
    public boolean aktywny = true;
    public boolean najechany = false;

    public Przycisk(String obrazek, int x, int y, int szerokosc, int wysokosc, Runnable akcja) {
        this.obrazek = obrazek;
        this.obszar = new Rectangle(x, y, szerokosc, wysokosc);
        this.akcja = akcja;
    }

    public boolean zawiera(int mx, int my) {
        return obszar.contains(mx, my);
    }

    public void kliknij() {
        if (aktywny) {
            akcja.run();
        }
    }
}
