import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.KeyEvent;
import java.util.List;

class WidokMenu {
    final PanelGry panel;

    private static final int PRZYCISK_X = 430, PRZYCISK_Y = 240, PRZYCISK_SZEROKOSC = 420, PRZYCISK_WYSOKOSC = 66, PRZYCISK_ODSTEP = 74;
    private static final Rectangle KARTKA = new Rectangle(320, 290, 640, 332);
    private static final Rectangle OKNO_INSTRUKCJI = new Rectangle(334, 300, 592, 312);
    private static final Rectangle TOR_PRZEWIJANIA = new Rectangle(938, 300, 12, 312);

    private static final Color KOLOR_TYTULU = new Color(62, 36, 20);
    private static final Color KOLOR_NAGLOWKA = new Color(130, 45, 30);
    private static final Color KOLOR_TEKSTU = new Color(25, 25, 35);
    private static final Color KOLOR_RAMKI = new Color(120, 85, 55);

    private static final String[] NAGLOWKI = {"Lp.", "Data", "Punkty", "Miejsce", "Gotówka", "Status"};
    private static final int[] KOLUMNA_X = {334, 372, 612, 702, 822, 838};
    private static final boolean[] DO_PRAWEJ = {false, false, true, true, true, false};

    private static final String[][] INSTRUKCJA = {
            {"Cel gry", "Poprowadź salon przez 8 etapów rozgrywki, utrzymaj płynność finansową i wyprzedź Orange, Play, Plus i T-Mobile. Wygrać i przegrać można równie łatwo."},
            {"Poruszanie się", "Chodź po planie salonu strzałkami lub W/A/S/D. Klawisz E (Enter, Spacja lub przycisk Interakcja) działa przy kliencie, biurku, drukarce i gablotach."},
            {"Obsługa klienta", "Zaproś klienta z kolejki (podejdź do niego i naciśnij E), usiądź przy biurku i rozmawiaj. Gdy klient prosi o telefon lub kartę SIM, weź towar z gabloty i połóż na biurku. Potem wydrukuj umowę w drukarce i zanieś ją na biurko."},
            {"Czas klienta", "Klienci mają ograniczoną cierpliwość (pasek nad głową, wykrzyknik przy końcu). Brak towaru lub zbyt długie czekanie oznacza utratę klienta i reputacji. Limit czasu wyłączysz w Ustawieniach."},
            {"Dokumenty i test", "Porównaj umowę z dowodem i notatkami, zaznacz błędy, potem odpowiedz na pytania testowe. Rozmowa, dokumenty i test składają się na satysfakcję klienta."},
            {"Biuro", "Komputer na biurku lub przycisk Biuro. Magazyn - zamówienia (dostawa w następnej turze), Marketing - więcej klientów, Szkolenia (od tury 4) - certyfikat usuwa jedną błędną odpowiedź w teście, Wskaźniki - plany naprawcze, gdy wskaźnik jest poza normą."},
            {"Koniec tury", "Przychód minus czynsz, media i rata kredytu. Wydarzenia losowe mogą pomóc lub zaszkodzić. Bankructwo: gotówka poniżej zera lub reputacja zero. Wygrywa salon z najlepszym wynikiem w rankingu po 8 turach."},
            {"Zapis i menu", "Gra zapisuje się na początku każdej tury (Kontynuuj grę). Esc lub przycisk Wróć do menu zatrzymuje grę, a z menu można do niej wrócić."}
    };

    private double przewiniecie;
    private int wysokoscTresci;
    private boolean przeciaganie;
    private int przesuniecieUchwytu;

    WidokMenu(PanelGry panel) {
        this.panel = panel;
    }

    void zbudujMenu() {
        String[] pliki = {"nowa_gra", "kontynuuj", "wyniki", "instrukcja", "ustawienia", "wyjscie"};
        Runnable[] akcje = {
                panel::rozpocznijNowaGre,
                panel::kontynuujGre,
                () -> panel.ustawEkran(PanelGry.Ekran.WYNIKI),
                () -> panel.ustawEkran(PanelGry.Ekran.INSTRUKCJA),
                () -> panel.ustawEkran(PanelGry.Ekran.USTAWIENIA),
                () -> System.exit(0)};
        for (int i = 0; i < pliki.length; i++) {
            panel.dodajPrzycisk("menu/" + pliki[i] + ".png", PRZYCISK_X, PRZYCISK_Y + i * PRZYCISK_ODSTEP,
                    PRZYCISK_SZEROKOSC, PRZYCISK_WYSOKOSC, akcje[i]);
        }
        panel.przyciski.get(1).aktywny = MenedzerPlikow.czyIstniejeZapis();
    }

    void zbudujInstrukcje() {
        przewiniecie = 0;
        przeciaganie = false;
        dodajPrzyciskPowrotu();
    }

    void zbudujWyniki() {
        dodajPrzyciskPowrotu();
    }

    void zbudujUstawienia() {
        String czcionka = panel.duzaCzcionka ? "czcionka_duza" : "czcionka_normalna";
        String limit = panel.limitCzasu ? "limit_wlaczony" : "limit_wylaczony";
        panel.dodajPrzycisk("menu/" + czcionka + ".png", 390, 365, 500, 85, () -> {
            panel.duzaCzcionka = !panel.duzaCzcionka;
            panel.ustawEkran(PanelGry.Ekran.USTAWIENIA);
        });
        panel.dodajPrzycisk("menu/" + limit + ".png", 390, 470, 500, 85, () -> {
            panel.limitCzasu = !panel.limitCzasu;
            panel.ustawEkran(PanelGry.Ekran.USTAWIENIA);
        });
        dodajPrzyciskPowrotu();
    }

    private void dodajPrzyciskPowrotu() {
        panel.dodajPrzycisk("menu/wroc.png", 490, 632, 300, 51, () -> panel.ustawEkran(PanelGry.Ekran.MENU));
    }

    private void rysujTlo(Graphics2D g) {
        g.drawImage(MenedzerPlikow.wczytajObraz("menu/tlo_menu.png", PanelGry.SZEROKOSC, PanelGry.WYSOKOSC), 0, 0, null);
    }

    private void rysujTytul(Graphics2D g, String tytul) {
        g.setFont(panel.czcionka(40, true));
        g.setColor(new Color(255, 255, 255, 110));
        panel.rysujWysrodkowany(g, tytul, PanelGry.SZEROKOSC / 2 + 1, 277);
        g.setColor(KOLOR_TYTULU);
        panel.rysujWysrodkowany(g, tytul, PanelGry.SZEROKOSC / 2, 276);
    }

    private void rysujKartke(Graphics2D g) {
        g.setColor(new Color(0, 0, 0, 50));
        g.fillRoundRect(KARTKA.x + 4, KARTKA.y + 5, KARTKA.width, KARTKA.height, 14, 14);
        g.setColor(new Color(250, 246, 232, 240));
        g.fillRoundRect(KARTKA.x, KARTKA.y, KARTKA.width, KARTKA.height, 14, 14);
        g.setColor(KOLOR_RAMKI);
        g.setStroke(new BasicStroke(2f));
        g.drawRoundRect(KARTKA.x, KARTKA.y, KARTKA.width, KARTKA.height, 14, 14);
    }

    void rysujMenu(Graphics2D g) {
        rysujTlo(g);
    }

    void rysujUstawienia(Graphics2D g) {
        rysujTlo(g);
        rysujTytul(g, "Ustawienia");
    }

    void rysujWyniki(Graphics2D g) {
        rysujTlo(g);
        rysujTytul(g, "Najlepsze wyniki");
        rysujKartke(g);
        List<String[]> wyniki = MenedzerPlikow.wczytajWyniki(8);
        if (wyniki.isEmpty()) {
            g.setFont(panel.czcionka(22, false));
            g.setColor(KOLOR_TEKSTU);
            panel.rysujWysrodkowany(g, "Brak zapisanych wyników - zagraj pierwszą partię!", PanelGry.SZEROKOSC / 2, KARTKA.y + 80);
            return;
        }
        int y = KARTKA.y + 34;
        g.setFont(panel.czcionka(19, true));
        g.setColor(KOLOR_NAGLOWKA);
        rysujWiersz(g, NAGLOWKI, y);
        g.setColor(KOLOR_RAMKI);
        g.setStroke(new BasicStroke(2f));
        g.drawLine(KARTKA.x + 16, y + 8, KARTKA.x + KARTKA.width - 16, y + 8);
        g.setFont(panel.czcionka(19, false));
        g.setColor(KOLOR_TEKSTU);
        for (int i = 0; i < wyniki.size(); i++) {
            String[] w = wyniki.get(i);
            rysujWiersz(g, new String[]{(i + 1) + ".", w[0], w[1], w[2] + " / 5", w[3] + " zł", w[4]}, y + 38 + i * 32);
        }
    }

    private void rysujWiersz(Graphics2D g, String[] komorki, int y) {
        for (int k = 0; k < komorki.length; k++) {
            if (DO_PRAWEJ[k]) {
                panel.rysujDoPrawej(g, komorki[k], KOLUMNA_X[k], y);
            } else {
                g.drawString(komorki[k], KOLUMNA_X[k], y);
            }
        }
    }

    void rysujInstrukcje(Graphics2D g) {
        rysujTlo(g);
        rysujTytul(g, "Instrukcja");
        rysujKartke(g);
        wysokoscTresci = ulozInstrukcje(g, false);
        przewin(0);
        Shape staryObszar = g.getClip();
        g.setClip(OKNO_INSTRUKCJI);
        ulozInstrukcje(g, true);
        g.setClip(staryObszar);
        Rectangle suwak = suwak();
        if (suwak != null) {
            g.setColor(new Color(200, 178, 140));
            g.fillRoundRect(TOR_PRZEWIJANIA.x, TOR_PRZEWIJANIA.y, TOR_PRZEWIJANIA.width, TOR_PRZEWIJANIA.height, 10, 10);
            g.setColor(przeciaganie ? new Color(70, 40, 20) : new Color(110, 70, 40));
            g.fillRoundRect(suwak.x, suwak.y, suwak.width, suwak.height, 10, 10);
        }
    }

    private int ulozInstrukcje(Graphics2D g, boolean rysuj) {
        Font czcionkaNaglowka = panel.czcionka(22, true), czcionkaTekstu = panel.czcionka(20, false);
        FontMetrics miaryNaglowka = g.getFontMetrics(czcionkaNaglowka), miaryTekstu = g.getFontMetrics(czcionkaTekstu);
        int y = OKNO_INSTRUKCJI.y - (rysuj ? (int) przewiniecie : 0) + miaryNaglowka.getAscent();
        int poczatek = y;
        for (String[] rozdzial : INSTRUKCJA) {
            if (rysuj) {
                g.setFont(czcionkaNaglowka);
                g.setColor(KOLOR_NAGLOWKA);
                g.drawString(rozdzial[0], OKNO_INSTRUKCJI.x + 4, y);
            }
            y += miaryNaglowka.getHeight();
            for (String wiersz : panel.zawinTekst(miaryTekstu, rozdzial[1], OKNO_INSTRUKCJI.width - 12)) {
                if (rysuj) {
                    g.setFont(czcionkaTekstu);
                    g.setColor(KOLOR_TEKSTU);
                    g.drawString(wiersz, OKNO_INSTRUKCJI.x + 4, y);
                }
                y += miaryTekstu.getHeight();
            }
            y += 12;
        }
        return y - poczatek + 4;
    }

    private int maksymalnePrzewiniecie() {
        return Math.max(0, wysokoscTresci - OKNO_INSTRUKCJI.height);
    }

    void przewin(double piksele) {
        przewiniecie = Math.max(0, Math.min(maksymalnePrzewiniecie(), przewiniecie + piksele));
    }

    void przewinKlawiszem(int klawisz) {
        switch (klawisz) {
            case KeyEvent.VK_UP: przewin(-40); break;
            case KeyEvent.VK_DOWN: przewin(40); break;
            case KeyEvent.VK_PAGE_UP: przewin(-(OKNO_INSTRUKCJI.height - 40)); break;
            case KeyEvent.VK_PAGE_DOWN: przewin(OKNO_INSTRUKCJI.height - 40); break;
            case KeyEvent.VK_HOME: przewin(-wysokoscTresci); break;
            case KeyEvent.VK_END: przewin(wysokoscTresci); break;
            default: break;
        }
    }

    private Rectangle suwak() {
        int maksimum = maksymalnePrzewiniecie();
        if (maksimum == 0) {
            return null;
        }
        int wysokosc = Math.max(36, TOR_PRZEWIJANIA.height * OKNO_INSTRUKCJI.height / wysokoscTresci);
        int y = TOR_PRZEWIJANIA.y + (int) ((TOR_PRZEWIJANIA.height - wysokosc) * (przewiniecie / maksimum));
        return new Rectangle(TOR_PRZEWIJANIA.x, y, TOR_PRZEWIJANIA.width, wysokosc);
    }

    boolean nacisnijPasekPrzewijania(Point p) {
        if (!TOR_PRZEWIJANIA.contains(p) || maksymalnePrzewiniecie() == 0) {
            return false;
        }
        Rectangle suwak = suwak();
        if (suwak.contains(p)) {
            przeciaganie = true;
            przesuniecieUchwytu = p.y - suwak.y;
        } else {
            przewin(p.y < suwak.y ? -(OKNO_INSTRUKCJI.height - 40) : OKNO_INSTRUKCJI.height - 40);
        }
        return true;
    }

    boolean przeciagnijSuwak(Point p) {
        if (!przeciaganie) {
            return false;
        }
        int zakres = TOR_PRZEWIJANIA.height - suwak().height;
        int y = Math.max(TOR_PRZEWIJANIA.y, Math.min(TOR_PRZEWIJANIA.y + zakres, p.y - przesuniecieUchwytu));
        przewiniecie = zakres <= 0 ? 0 : (y - TOR_PRZEWIJANIA.y) / (double) zakres * maksymalnePrzewiniecie();
        return true;
    }

    void zwolnijPasekPrzewijania() {
        przeciaganie = false;
    }
}
