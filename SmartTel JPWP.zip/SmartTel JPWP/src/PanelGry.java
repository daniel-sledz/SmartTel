import javax.swing.JPanel;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("serial")
public class PanelGry extends JPanel implements MouseListener, MouseMotionListener, MouseWheelListener, KeyListener {

    static final int SZEROKOSC = 1280, WYSOKOSC = 720;

    enum Ekran { MENU, INSTRUKCJA, WYNIKI, USTAWIENIA }

    Ekran ekran = Ekran.MENU;
    final List<Przycisk> przyciski = new ArrayList<>();
    final WidokMenu widokMenu = new WidokMenu(this);

    boolean duzaCzcionka = false;
    boolean limitCzasu = true;

    private double skala = 1, przesuniecieX = 0, przesuniecieY = 0;

    public PanelGry() {
        setPreferredSize(new Dimension(SZEROKOSC, WYSOKOSC));
        setBackground(Color.BLACK);
        setFocusable(true);
        addMouseListener(this);
        addMouseMotionListener(this);
        addMouseWheelListener(this);
        addKeyListener(this);
        ustawEkran(Ekran.MENU);
    }

    Przycisk dodajPrzycisk(String obrazek, int x, int y, int szerokosc, int wysokosc, Runnable akcja) {
        Przycisk przycisk = new Przycisk(obrazek, x, y, szerokosc, wysokosc, akcja);
        przyciski.add(przycisk);
        return przycisk;
    }

    void ustawEkran(Ekran nowyEkran) {
        ekran = nowyEkran;
        przyciski.clear();
        switch (nowyEkran) {
            case MENU: widokMenu.zbudujMenu(); break;
            case INSTRUKCJA: widokMenu.zbudujInstrukcje(); break;
            case WYNIKI: widokMenu.zbudujWyniki(); break;
            case USTAWIENIA: widokMenu.zbudujUstawienia(); break;
        }
        requestFocusInWindow();
        repaint();
    }

    void rozpocznijNowaGre() {
        System.out.println("Nowa gra: rozgrywka jest w przygotowaniu.");
    }

    void kontynuujGre() {
        System.out.println("Kontynuacja gry: rozgrywka jest w przygotowaniu.");
    }

    @Override
    protected void paintComponent(Graphics g0) {
        super.paintComponent(g0);
        Graphics2D g = (Graphics2D) g0.create();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        skala = Math.min(getWidth() / (double) SZEROKOSC, getHeight() / (double) WYSOKOSC);
        przesuniecieX = (getWidth() - SZEROKOSC * skala) / 2;
        przesuniecieY = (getHeight() - WYSOKOSC * skala) / 2;
        g.translate(przesuniecieX, przesuniecieY);
        g.scale(skala, skala);
        g.setClip(0, 0, SZEROKOSC, WYSOKOSC);

        switch (ekran) {
            case MENU: widokMenu.rysujMenu(g); break;
            case INSTRUKCJA: widokMenu.rysujInstrukcje(g); break;
            case WYNIKI: widokMenu.rysujWyniki(g); break;
            case USTAWIENIA: widokMenu.rysujUstawienia(g); break;
        }
        for (Przycisk przycisk : przyciski) {
            rysujPrzycisk(g, przycisk);
        }
        g.dispose();
    }

    private void rysujPrzycisk(Graphics2D g, Przycisk przycisk) {
        Rectangle r = przycisk.obszar;
        g.drawImage(MenedzerPlikow.wczytajObraz(przycisk.obrazek, r.width, r.height), r.x, r.y, null);
        if (!przycisk.aktywny) {
            g.setColor(new Color(0, 0, 0, 120));
            g.fillRoundRect(r.x, r.y, r.width, r.height, 14, 14);
        } else if (przycisk.najechany) {
            g.setColor(new Color(255, 205, 60));
            g.setStroke(new BasicStroke(4f));
            g.drawRoundRect(r.x - 2, r.y - 2, r.width + 4, r.height + 4, 16, 16);
        }
    }

    Font czcionka(int rozmiar, boolean pogrubiona) {
        return new Font("SansSerif", pogrubiona ? Font.BOLD : Font.PLAIN, rozmiar);
    }

    List<String> zawinTekst(FontMetrics miary, String tekst, int maksymalnaSzerokosc) {
        List<String> wiersze = new ArrayList<>();
        String wiersz = "";
        for (String slowo : tekst.split(" ")) {
            String proba = wiersz.isEmpty() ? slowo : wiersz + " " + slowo;
            if (miary.stringWidth(proba) > maksymalnaSzerokosc && !wiersz.isEmpty()) {
                wiersze.add(wiersz);
                wiersz = slowo;
            } else {
                wiersz = proba;
            }
        }
        wiersze.add(wiersz);
        return wiersze;
    }

    void rysujWysrodkowany(Graphics2D g, String tekst, int srodekX, int y) {
        g.drawString(tekst, srodekX - g.getFontMetrics().stringWidth(tekst) / 2, y);
    }

    void rysujDoPrawej(Graphics2D g, String tekst, int prawyX, int y) {
        g.drawString(tekst, prawyX - g.getFontMetrics().stringWidth(tekst), y);
    }

    private Point naWspolrzedneWirtualne(MouseEvent e) {
        return new Point((int) ((e.getX() - przesuniecieX) / skala), (int) ((e.getY() - przesuniecieY) / skala));
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        Point p = naWspolrzedneWirtualne(e);
        boolean nadPrzyciskiem = false;
        for (Przycisk przycisk : przyciski) {
            przycisk.najechany = przycisk.zawiera(p.x, p.y);
            nadPrzyciskiem |= przycisk.najechany && przycisk.aktywny;
        }
        setCursor(Cursor.getPredefinedCursor(nadPrzyciskiem ? Cursor.HAND_CURSOR : Cursor.DEFAULT_CURSOR));
        repaint();
    }

    @Override
    public void mousePressed(MouseEvent e) {
        if (e.getButton() != MouseEvent.BUTTON1) {
            return;
        }
        Point p = naWspolrzedneWirtualne(e);
        if (ekran == Ekran.INSTRUKCJA && widokMenu.nacisnijPasekPrzewijania(p)) {
            repaint();
            return;
        }
        for (Przycisk przycisk : przyciski) {
            if (przycisk.zawiera(p.x, p.y)) {
                przycisk.kliknij();
                break;
            }
        }
        repaint();
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        if (ekran == Ekran.INSTRUKCJA && widokMenu.przeciagnijSuwak(naWspolrzedneWirtualne(e))) {
            repaint();
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        widokMenu.zwolnijPasekPrzewijania();
    }

    @Override
    public void mouseWheelMoved(MouseWheelEvent e) {
        if (ekran == Ekran.INSTRUKCJA) {
            widokMenu.przewin(e.getWheelRotation() * 48);
            repaint();
        }
    }

    @Override public void mouseClicked(MouseEvent e) { }
    @Override public void mouseEntered(MouseEvent e) { }
    @Override public void mouseExited(MouseEvent e) { }

    @Override
    public void keyPressed(KeyEvent e) {
        int klawisz = e.getKeyCode();
        if (klawisz == KeyEvent.VK_ESCAPE && ekran != Ekran.MENU) {
            ustawEkran(Ekran.MENU);
        } else if (ekran == Ekran.INSTRUKCJA) {
            widokMenu.przewinKlawiszem(klawisz);
            repaint();
        }
    }

    @Override public void keyTyped(KeyEvent e) { }
    @Override public void keyReleased(KeyEvent e) { }
}
