import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import java.awt.Dimension;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame okno = new JFrame("SmartTel - gra edukacyjna");
            okno.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            PanelGry panel = new PanelGry();
            okno.setContentPane(panel);
            okno.pack();
            okno.setMinimumSize(new Dimension(960, 540));
            okno.setLocationRelativeTo(null);
            okno.setVisible(true);
            panel.requestFocusInWindow();
        });
    }
}
