import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MenedzerPlikow {
    private static final Path PLIK_WYNIKOW = Paths.get("wyniki.txt");
    private static final Path PLIK_ZAPISU = Paths.get("zapis_gry.properties");

    private static final Map<String, BufferedImage> obrazy = new HashMap<>();
    private static final Map<String, BufferedImage> obrazySkalowane = new HashMap<>();

    public static BufferedImage wczytajObraz(String nazwa) {
        if (!obrazy.containsKey(nazwa)) {
            try {
                obrazy.put(nazwa, ImageIO.read(new File("grafika", nazwa)));
            } catch (IOException e) {
                System.err.println("Nie można wczytać grafiki " + nazwa + ": " + e.getMessage());
                obrazy.put(nazwa, null);
            }
        }
        return obrazy.get(nazwa);
    }

    public static BufferedImage wczytajObraz(String nazwa, int szerokosc, int wysokosc) {
        String klucz = nazwa + "@" + szerokosc + "x" + wysokosc;
        if (!obrazySkalowane.containsKey(klucz)) {
            obrazySkalowane.put(klucz, zmienRozmiar(wczytajObraz(nazwa), szerokosc, wysokosc));
        }
        return obrazySkalowane.get(klucz);
    }

    private static BufferedImage zmienRozmiar(BufferedImage obraz, int szerokosc, int wysokosc) {
        int sz = obraz.getWidth(), wy = obraz.getHeight();
        while (sz / 2 >= szerokosc && wy / 2 >= wysokosc) {
            sz /= 2;
            wy /= 2;
            obraz = skaluj(obraz, sz, wy);
        }
        return skaluj(obraz, szerokosc, wysokosc);
    }

    private static BufferedImage skaluj(BufferedImage obraz, int szerokosc, int wysokosc) {
        BufferedImage wynik = new BufferedImage(szerokosc, wysokosc, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = wynik.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.drawImage(obraz, 0, 0, szerokosc, wysokosc, null);
        g.dispose();
        return wynik;
    }

    public static List<String[]> wczytajWyniki(int limit) {
        List<String[]> wyniki = new ArrayList<>();
        if (Files.exists(PLIK_WYNIKOW)) {
            try {
                for (String wiersz : Files.readAllLines(PLIK_WYNIKOW, StandardCharsets.UTF_8)) {
                    String[] pola = wiersz.split(";");
                    if (pola.length >= 5) {
                        wyniki.add(pola);
                    }
                }
            } catch (IOException e) {
                System.err.println("Nie można odczytać wyników: " + e.getMessage());
            }
        }
        wyniki.sort((a, b) -> Long.compare(liczba(b[1]), liczba(a[1])));
        return wyniki.size() > limit ? new ArrayList<>(wyniki.subList(0, limit)) : wyniki;
    }

    private static long liczba(String tekst) {
        try {
            return Long.parseLong(tekst.trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    public static boolean czyIstniejeZapis() {
        return Files.exists(PLIK_ZAPISU);
    }
}
